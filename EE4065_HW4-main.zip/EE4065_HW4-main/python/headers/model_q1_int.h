#pragma once
#include <stdint.h>

static const int16_t hu_mean_q[7] = { 10952, 1467, 268, 46, 0, 5, 0 };
static const int16_t hu_std_q[7] = { 2754, 2089, 461, 85, 3, 24, 2 };
static const int16_t w_q1_q[7] = { -7242, 17755, 30218, 18887, -2432, -8610, 7884 };
static const int16_t b_q1_q[1] = { 31208 };
static const int32_t q1_scale = 247311;
