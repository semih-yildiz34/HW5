"""
Generate C header files for STM32 from quantized parameters
"""
import os
import numpy as np

script_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(script_dir)
params_dir = os.path.join(parent_dir, "params")
headers_dir = os.path.join(parent_dir, "headers")

data = np.load(os.path.join(params_dir, "quantized_params_q15.npz"))

def c_array(name, arr, dtype="int16_t"):
    """Generate C array declaration"""
    flat = arr.flatten()
    values = ", ".join(str(int(x)) for x in flat)
    return f"static const {dtype} {name}[{len(flat)}] = {{ {values} }};\n"

os.makedirs(headers_dir, exist_ok=True)

# Q1 header
q1_scale = float(data["q1_scale"])
q1_scale_q15 = int(np.round(q1_scale * 32768))

with open(os.path.join(headers_dir, "model_q1_int.h"), "w") as f:
    f.write("#pragma once\n")
    f.write("#include <stdint.h>\n\n")
    f.write(c_array("hu_mean_q", data["mean_q1_q"]))
    f.write(c_array("hu_std_q", data["std_q1_q"]))
    f.write(c_array("w_q1_q", data["w_q1_q"]))
    f.write(c_array("b_q1_q", data["b_q1_q"]))
    f.write(f"static const int32_t q1_scale = {q1_scale_q15};\n")

# Q2 header
with open(os.path.join(headers_dir, "model_q2_int.h"), "w") as f:
    f.write("#pragma once\n")
    f.write("#include <stdint.h>\n\n")
    f.write(c_array("hu_mean_q2", data["mean_q2_q"]))
    f.write(c_array("hu_std_q2", data["std_q2_q"]))
    f.write(c_array("W1_q", data["W1_q"]))
    f.write(c_array("b1_q", data["b1_q"]))
    f.write(c_array("W2_q", data["W2_q"]))
    f.write(c_array("b2_q", data["b2_q"]))
    f.write(c_array("W3_q", data["W3_q"]))
    f.write(c_array("b3_q", data["b3_q"]))

print(f"Generated: headers/model_q1_int.h, headers/model_q2_int.h")
