"""
Extract weights and biases from trained Keras models
"""
import os
import numpy as np
import tensorflow as tf

script_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(script_dir)
models_dir = os.path.join(parent_dir, "models")
params_dir = os.path.join(parent_dir, "params")

# Load normalization stats (saved during training)
stats_q1 = np.load(os.path.join(params_dir, "mnist_hu_norm_stats.npz"))
mean_q1 = stats_q1["mean"]
std_q1 = stats_q1["std"]

stats_q2 = np.load(os.path.join(params_dir, "mnist_hu_norm_stats_q2.npz"))
mean_q2 = stats_q2["mean"]
std_q2 = stats_q2["std"]

print("Q1 Normalization stats:")
print("  mean:", mean_q1)
print("  std :", std_q1)

print("\nQ2 Normalization stats:")
print("  mean:", mean_q2)
print("  std :", std_q2)

# Q1: Single neuron model
model_q1 = tf.keras.models.load_model(os.path.join(models_dir, "mnist_single_neuron.h5"))
w_q1, b_q1 = model_q1.get_weights()
w_q1 = w_q1.flatten()

print("\nQ1 (Single Neuron):")
print("  weights:", w_q1)
print("  bias   :", b_q1)

# Q2: MLP model
model_q2 = tf.keras.models.load_model(os.path.join(models_dir, "mlp_mnist_model.h5"))
W1, b1, W2, b2, W3, b3 = model_q2.get_weights()

# Transpose weights to match STM32 indexing:
# Keras: W[input_features, output_neurons]
# STM32: W[output_neurons, input_features] (row-major: W[i*input_size + j])
W1 = W1.T  # (7, 100) -> (100, 7)
W2 = W2.T  # (100, 100) -> (100, 100) (symmetric, but transpose for consistency)
W3 = W3.T  # (100, 10) -> (10, 100)

print("\nQ2 (MLP) - Transposed for STM32:")
print("  W1:", W1.shape, "b1:", b1.shape)
print("  W2:", W2.shape, "b2:", b2.shape)
print("  W3:", W3.shape, "b3:", b3.shape)

# Save all parameters
os.makedirs(params_dir, exist_ok=True)
np.savez(
    os.path.join(params_dir, "extracted_params.npz"),
    mean_q1=mean_q1, std_q1=std_q1,  # Q1 normalization stats
    mean_q2=mean_q2, std_q2=std_q2,  # Q2 normalization stats
    w_q1=w_q1, b_q1=b_q1,
    W1=W1, b1=b1,
    W2=W2, b2=b2,
    W3=W3, b3=b3
)

print(f"\nSaved to params/extracted_params.npz")
