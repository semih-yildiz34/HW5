"""
Quantize extracted parameters to Q15 format for STM32
"""
import os
import numpy as np

script_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(script_dir)
params_dir = os.path.join(parent_dir, "params")

SCALE = 32768  # Q15

data = np.load(os.path.join(params_dir, "extracted_params.npz"))

def to_q15(x):
    """Convert float to Q15 (int16)"""
    return np.round(x * SCALE).astype(np.int16)

# Normalization stats (Q1 and Q2 use different stats)
mean_q1_q = to_q15(data["mean_q1"])
std_q1_q = to_q15(data["std_q1"])
mean_q2_q = to_q15(data["mean_q2"])
std_q2_q = to_q15(data["std_q2"])

# Q1: Scale weights/bias to fit in Q15 range
w_q1 = data["w_q1"]
b_q1 = data["b_q1"]
q1_max = max(np.abs(w_q1).max(), np.abs(b_q1).max())
q1_scale = q1_max * 1.05  # Small margin

w_q1_q = to_q15(w_q1 / q1_scale)
b_q1_q = to_q15(b_q1 / q1_scale)

print("Q1:")
print(f"  max value: {q1_max:.4f}")
print(f"  scale factor: {q1_scale:.4f}")
print(f"  weights Q15: {w_q1_q}")
print(f"  bias Q15: {b_q1_q}")

# Q2: MLP layers
W1_q = to_q15(data["W1"])
b1_q = to_q15(data["b1"])
W2_q = to_q15(data["W2"])
b2_q = to_q15(data["b2"])
W3_q = to_q15(data["W3"])
b3_q = to_q15(data["b3"])

print("\nQ2:")
print(f"  W1 range: [{data['W1'].min():.4f}, {data['W1'].max():.4f}]")
print(f"  W2 range: [{data['W2'].min():.4f}, {data['W2'].max():.4f}]")
print(f"  W3 range: [{data['W3'].min():.4f}, {data['W3'].max():.4f}]")

# Save quantized parameters
np.savez(
    os.path.join(params_dir, "quantized_params_q15.npz"),
    mean_q1_q=mean_q1_q, std_q1_q=std_q1_q,  # Q1 normalization stats
    mean_q2_q=mean_q2_q, std_q2_q=std_q2_q,  # Q2 normalization stats
    w_q1_q=w_q1_q, b_q1_q=b_q1_q, q1_scale=q1_scale,
    W1_q=W1_q, b1_q=b1_q,
    W2_q=W2_q, b2_q=b2_q,
    W3_q=W3_q, b3_q=b3_q
)

print(f"\nSaved to params/quantized_params_q15.npz")
