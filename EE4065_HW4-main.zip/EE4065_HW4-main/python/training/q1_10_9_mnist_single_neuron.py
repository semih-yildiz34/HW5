import os
import struct
import numpy as np
import cv2
import tensorflow as tf
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from matplotlib import pyplot as plt


# -----------------------------
# MNIST IDX loaders (offline)
# -----------------------------
def load_images(path: str) -> np.ndarray:
    with open(path, "rb") as f:
        magic, num, rows, cols = struct.unpack(">IIII", f.read(16))
        if magic != 2051:
            raise ValueError(f"Invalid magic number for images: {magic} in {path}")
        data = np.frombuffer(f.read(), dtype=np.uint8)
        images = data.reshape(num, rows, cols)
    return images


def load_labels(path: str) -> np.ndarray:
    with open(path, "rb") as f:
        magic, num = struct.unpack(">II", f.read(8))
        if magic != 2049:
            raise ValueError(f"Invalid magic number for labels: {magic} in {path}")
        labels = np.frombuffer(f.read(), dtype=np.uint8)
        if labels.shape[0] != num:
            raise ValueError("Label count mismatch.")
    return labels


# -----------------------------
# Main
# -----------------------------
def main():
    # 1) Paths - use parent directory as base (one level up from training/)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(script_dir)  # Go up one level to python/
    train_img_path = os.path.join(parent_dir, "MNIST-dataset", "train-images.idx3-ubyte")
    train_lbl_path = os.path.join(parent_dir, "MNIST-dataset", "train-labels.idx1-ubyte")
    test_img_path  = os.path.join(parent_dir, "MNIST-dataset", "t10k-images.idx3-ubyte")
    test_lbl_path  = os.path.join(parent_dir, "MNIST-dataset", "t10k-labels.idx1-ubyte")

    # Quick file existence check
    for p in [train_img_path, train_lbl_path, test_img_path, test_lbl_path]:
        if not os.path.exists(p):
            raise FileNotFoundError(f"Missing file: {p}")

    # 2) Load data
    train_images = load_images(train_img_path)
    train_labels = load_labels(train_lbl_path)
    test_images  = load_images(test_img_path)
    test_labels  = load_labels(test_lbl_path)

    print("Loaded:")
    print(" train_images:", train_images.shape, train_images.dtype)
    print(" train_labels:", train_labels.shape, train_labels.dtype)
    print(" test_images :", test_images.shape, test_images.dtype)
    print(" test_labels :", test_labels.shape, test_labels.dtype)

    # 3) Extract Hu Moments (7 features per image)
    train_hu = np.empty((len(train_images), 7), dtype=np.float32)
    test_hu  = np.empty((len(test_images), 7), dtype=np.float32)

    for i, img in enumerate(train_images):
        m = cv2.moments(img, binaryImage=True)
        hu = cv2.HuMoments(m).reshape(7)
        train_hu[i] = hu

    for i, img in enumerate(test_images):
        m = cv2.moments(img, binaryImage=True)
        hu = cv2.HuMoments(m).reshape(7)
        test_hu[i] = hu

    # 4) Normalize using train stats
    features_mean = np.mean(train_hu, axis=0)
    features_std  = np.std(train_hu, axis=0)
    # avoid divide-by-zero (shouldn't happen, but safe)
    features_std = np.where(features_std == 0, 1.0, features_std)

    train_hu = (train_hu - features_mean) / features_std
    test_hu  = (test_hu  - features_mean) / features_std

    # 5) Make labels binary: 0 vs not-0
    train_y = train_labels.copy()
    test_y  = test_labels.copy()
    train_y[train_y != 0] = 1
    test_y[test_y != 0] = 1

    # 6) Build single neuron classifier
    model = tf.keras.models.Sequential([
        tf.keras.layers.Dense(1, input_shape=[7], activation="sigmoid")
    ])

    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
        loss=tf.keras.losses.BinaryCrossentropy(),
        metrics=[tf.keras.metrics.BinaryAccuracy()]
    )

    # Class weight (optional; kitapta var)
    class_weight = {0: 0.8, 1: 1.0}

    history = model.fit(
        train_hu, train_y,
        batch_size=128,
        epochs=50,
        verbose=1,
        class_weight=class_weight
    )

    # 7) Predict + confusion matrix
    probs = model.predict(test_hu, verbose=0).reshape(-1)
    preds = (probs > 0.5).astype(np.uint8)

    cm = confusion_matrix(test_y, preds, labels=[0, 1])
    print("\nConfusion matrix (rows=true, cols=pred) [0,1]:\n", cm)

    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=[0, 1])
    disp.plot()
    disp.ax_.set_title("Single Neuron Classifier Confusion Matrix (0 vs not-0)")
    
    # Save confusion matrix image
    output_dir = os.path.join(parent_dir, "outputs")
    os.makedirs(output_dir, exist_ok=True)
    plt.savefig(os.path.join(output_dir, "Single Neuron Classifier Confusion Matrix (0 vs not-0).jpg"))
    plt.show()

    # 8) Save model
    models_dir = os.path.join(parent_dir, "models")
    os.makedirs(models_dir, exist_ok=True)
    model_path = os.path.join(models_dir, "mnist_single_neuron.h5")
    model.save(model_path)
    print(f"\nSaved model: {model_path}")

    # Optional: also save normalization stats for STM32 integration
    params_dir = os.path.join(parent_dir, "params")
    os.makedirs(params_dir, exist_ok=True)
    stats_path = os.path.join(params_dir, "mnist_hu_norm_stats.npz")
    np.savez(stats_path, mean=features_mean, std=features_std)
    print(f"Saved normalization stats: {stats_path}")


if __name__ == "__main__":
    main()
