"""
test_python_simulation.py
Test digit recognition using Python simulation (stm32_predict.py)
Generates separate CSV for comparison with actual STM32 results
"""

import os
import sys
import csv
import time
from datetime import datetime

# Import the stm32_predict module functions
sys.path.insert(0, os.path.dirname(__file__))
from stm32_predict import process_image

# ============================================================================
# CONFIGURATION
# ============================================================================
TEST_IMAGES_DIR = os.path.join(os.path.dirname(__file__), "test_images")
NUM_CYCLES = 10
OUTPUT_CSV = os.path.join(os.path.dirname(__file__), "python_simulation_results.csv")

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================
def get_test_images():
    """Get list of test images in order (digit_0.png through digit_9.png)"""
    images = []
    for i in range(10):
        img_path = os.path.join(TEST_IMAGES_DIR, f"digit_{i}.png")
        if os.path.exists(img_path):
            images.append((i, img_path))
    return images

# ============================================================================
# MAIN PROGRAM
# ============================================================================
def main():
    print("="*70)
    print("Python Simulation Test - STM32 Prediction Logic")
    print("="*70)
    print(f"Test Images Directory: {TEST_IMAGES_DIR}")
    print(f"Number of Cycles: {NUM_CYCLES}")
    print(f"Output CSV: {OUTPUT_CSV}")
    print("="*70)
    
    # Get test images
    test_images = get_test_images()
    if len(test_images) == 0:
        print(f"\nERROR: No test images found in {TEST_IMAGES_DIR}")
        return
    
    print(f"\nFound {len(test_images)} test images:")
    for digit, path in test_images:
        print(f"  digit_{digit}.png")
    
    # Prepare CSV file
    csv_file = open(OUTPUT_CSV, 'w', newline='')
    csv_writer = csv.writer(csv_file)
    csv_writer.writerow(['sent_digit', 'q1_received', 'q2_received'])
    
    total_tests = NUM_CYCLES * len(test_images)
    test_count = 0
    success_count = 0
    
    try:
        print(f"\n{'='*70}")
        print(f"Starting Python simulation test: {NUM_CYCLES} cycles × {len(test_images)} images = {total_tests} total tests")
        print(f"{'='*70}\n")
        
        for cycle in range(1, NUM_CYCLES + 1):
            print(f"\n--- CYCLE {cycle}/{NUM_CYCLES} ---")
            
            for digit, image_path in test_images:
                test_count += 1
                
                print(f"\n[{test_count}/{total_tests}] Processing digit_{digit}.png...")
                
                try:
                    # Process image using Python simulation (quiet mode)
                    q1_result, q2_result = process_image(image_path, quiet=True)
                    
                    if q1_result is not None and q2_result is not None:
                        success_count += 1
                        print(f"  ✓ Sent: {digit}, Q1: {q1_result}, Q2: {q2_result}")
                        csv_writer.writerow([digit, q1_result, q2_result])
                        csv_file.flush()  # Ensure data is written immediately
                    else:
                        print(f"  ✗ ERROR: Failed to get predictions")
                        csv_writer.writerow([digit, 'ERROR', 'ERROR'])
                        csv_file.flush()
                    
                    # If this is the last image (digit_9) of the last cycle, we're done
                    if cycle == NUM_CYCLES and digit == 9:
                        print(f"\n{'='*70}")
                        print(f"Python simulation test complete!")
                        print(f"  Total tests: {test_count}")
                        print(f"  Successful: {success_count}")
                        print(f"  Failed: {test_count - success_count}")
                        print(f"  Results saved to: {OUTPUT_CSV}")
                        print(f"{'='*70}")
                        csv_file.close()
                        return
                
                except Exception as e:
                    print(f"  ✗ ERROR processing digit {digit}: {e}")
                    csv_writer.writerow([digit, 'ERROR', 'ERROR'])
                    csv_file.flush()
                    import traceback
                    traceback.print_exc()
        
        # Final summary (shouldn't reach here if ending after digit_9)
        print(f"\n{'='*70}")
        print(f"Python simulation test complete!")
        print(f"  Total tests: {test_count}")
        print(f"  Successful: {success_count}")
        print(f"  Failed: {test_count - success_count}")
        print(f"  Results saved to: {OUTPUT_CSV}")
        print(f"{'='*70}")
        csv_file.close()
        
    except KeyboardInterrupt:
        print("\n\nProgram stopped by user (Ctrl+C)")
        print(f"Partial results saved to: {OUTPUT_CSV}")
        csv_file.close()
    except Exception as e:
        print(f"\n\nERROR: An error occurred: {e}")
        import traceback
        traceback.print_exc()
        csv_file.close()

if __name__ == "__main__":
    main()

