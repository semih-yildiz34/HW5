"""
Check STM32 Firmware Version
Connects to STM32 and reads the version string sent at startup
"""

import serial
import time
import sys

COM_PORT = "COM3"  # Update if needed

def main():
    print("="*70)
    print("STM32 Firmware Version Checker")
    print("="*70)
    print(f"COM Port: {COM_PORT}")
    print("\nInstructions:")
    print("1. Make sure STM32 is connected and powered on")
    print("2. Press the RESET button on the STM32 board")
    print("3. This script will read the version string sent at startup")
    print("="*70)
    
    try:
        # Open serial port
        ser = serial.Serial(COM_PORT, 2000000, timeout=2)
        print(f"\n✓ Connected to {COM_PORT}")
        print("Waiting for version string...")
        print("(Press RESET button on STM32 if nothing appears)\n")
        
        # Clear any existing data
        ser.reset_input_buffer()
        
        # Wait a bit for the board to send the version
        time.sleep(0.5)
        
        # Read for 2 seconds
        start_time = time.time()
        buffer = b""
        
        while time.time() - start_time < 2.0:
            if ser.in_waiting > 0:
                data = ser.read(ser.in_waiting)
                buffer += data
                # Check if we got the version string
                if b"STM32_DigitRec" in buffer:
                    # Extract version line
                    lines = buffer.split(b'\r\n')
                    for line in lines:
                        if b"STM32_DigitRec" in line:
                            version = line.decode('ascii', errors='ignore')
                            print(f"✓ Firmware Version: {version}")
                            
                            if b"v2.0" in line:
                                print("\n✓ CORRECT VERSION - Sigmoid fix is included!")
                            else:
                                print("\n⚠ OLD VERSION - Please rebuild and reflash!")
                            
                            ser.close()
                            return
            
            time.sleep(0.1)
        
        # If we got here, no version string was found
        print("\n⚠ No version string received!")
        print("Possible issues:")
        print("  1. Firmware not flashed correctly")
        print("  2. Wrong COM port")
        print("  3. STM32 not powered/reset")
        print("\nReceived data:", buffer[:100] if buffer else "(none)")
        
        ser.close()
        
    except serial.SerialException as e:
        print(f"\n✗ ERROR: Could not open serial port: {e}")
        print(f"Please check that COM port '{COM_PORT}' is correct")
    except Exception as e:
        print(f"\n✗ ERROR: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()

