"""
analyze_results.py
Analyze test results CSV to check prediction accuracy
Can analyze both STM32 results and Python simulation results separately
"""

import csv
import os
import sys

# ============================================================================
# CONFIGURATION
# ============================================================================
STM32_CSV = os.path.join(os.path.dirname(__file__), "stm32_test_results.csv")
PYTHON_CSV = os.path.join(os.path.dirname(__file__), "python_simulation_results.csv")

# ============================================================================
# ANALYSIS FUNCTIONS
# ============================================================================
def analyze_results(csv_path, source_name="Test Results"):
    """
    Analyze the CSV file and calculate accuracy statistics.
    """
    if not os.path.exists(csv_path):
        print(f"ERROR: CSV file not found: {csv_path}")
        return None
    
    # Read CSV data
    results = []
    with open(csv_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                sent_digit = int(row['sent_digit'])
                q1_received = int(row['q1_received']) if row['q1_received'] != 'ERROR' else None
                q2_received = int(row['q2_received']) if row['q2_received'] != 'ERROR' else None
                results.append({
                    'sent': sent_digit,
                    'q1': q1_received,
                    'q2': q2_received
                })
            except (ValueError, KeyError) as e:
                print(f"Warning: Skipping invalid row: {row}")
                continue
    
    if len(results) == 0:
        print(f"ERROR: No valid results found in CSV file: {csv_path}")
        return None
    
    # Calculate Q1 accuracy (binary: 0 vs not-0)
    # Q1 should be 0 if sent_digit == 0, and 1 if sent_digit != 0
    q1_correct = 0
    q1_total = 0
    q1_errors = []
    
    for r in results:
        if r['q1'] is not None:
            q1_total += 1
            expected_q1 = 0 if r['sent'] == 0 else 1
            if r['q1'] == expected_q1:
                q1_correct += 1
            else:
                q1_errors.append({
                    'sent': r['sent'],
                    'expected_q1': expected_q1,
                    'received_q1': r['q1']
                })
    
    # Calculate Q2 accuracy (digit classification: 0-9)
    q2_correct = 0
    q2_total = 0
    q2_errors = []
    q2_per_digit = {i: {'correct': 0, 'total': 0, 'errors': []} for i in range(10)}
    
    for r in results:
        if r['q2'] is not None:
            q2_total += 1
            q2_per_digit[r['sent']]['total'] += 1
            if r['q2'] == r['sent']:
                q2_correct += 1
                q2_per_digit[r['sent']]['correct'] += 1
            else:
                q2_errors.append({
                    'sent': r['sent'],
                    'received': r['q2']
                })
                q2_per_digit[r['sent']]['errors'].append(r['q2'])
    
    # Print results
    print("="*70)
    print(f"{source_name} Analysis")
    print("="*70)
    print(f"Total test cases: {len(results)}")
    print()
    
    # Q1 Results
    print("="*70)
    print("Q1 (Single Neuron - Binary: 0 vs NOT-0)")
    print("="*70)
    if q1_total > 0:
        q1_accuracy = (q1_correct / q1_total) * 100
        print(f"Correct: {q1_correct}/{q1_total}")
        print(f"Accuracy: {q1_accuracy:.2f}%")
        print(f"Errors: {len(q1_errors)}")
        
        if len(q1_errors) > 0:
            print("\nQ1 Errors:")
            for err in q1_errors[:10]:  # Show first 10 errors
                print(f"  Sent digit {err['sent']}: Expected Q1={err['expected_q1']}, Got Q1={err['received_q1']}")
            if len(q1_errors) > 10:
                print(f"  ... and {len(q1_errors) - 10} more errors")
    else:
        print("No Q1 results available")
    
    print()
    
    # Q2 Results
    print("="*70)
    print("Q2 (MLP - Digit Classification: 0-9)")
    print("="*70)
    if q2_total > 0:
        q2_accuracy = (q2_correct / q2_total) * 100
        print(f"Correct: {q2_correct}/{q2_total}")
        print(f"Accuracy: {q2_accuracy:.2f}%")
        print(f"Errors: {len(q2_errors)}")
        
        # Per-digit accuracy
        print("\nPer-Digit Accuracy (Q2):")
        print(f"{'Digit':<8} {'Correct':<10} {'Total':<8} {'Accuracy':<10} {'Most Common Error':<20}")
        print("-" * 70)
        for digit in range(10):
            stats = q2_per_digit[digit]
            if stats['total'] > 0:
                acc = (stats['correct'] / stats['total']) * 100
                # Find most common error
                if len(stats['errors']) > 0:
                    from collections import Counter
                    error_counts = Counter(stats['errors'])
                    most_common_error = f"{error_counts.most_common(1)[0][0]} (x{error_counts.most_common(1)[0][1]})"
                else:
                    most_common_error = "None"
                print(f"{digit:<8} {stats['correct']:<10} {stats['total']:<8} {acc:>6.2f}%     {most_common_error:<20}")
            else:
                print(f"{digit:<8} {'N/A':<10} {'0':<8} {'N/A':<10} {'No data':<20}")
        
        # Show some Q2 errors
        if len(q2_errors) > 0:
            print(f"\nQ2 Errors (showing first 20):")
            error_summary = {}
            for err in q2_errors[:20]:
                key = f"{err['sent']} -> {err['received']}"
                error_summary[key] = error_summary.get(key, 0) + 1
                print(f"  Sent {err['sent']}, Predicted {err['received']}")
            if len(q2_errors) > 20:
                print(f"  ... and {len(q2_errors) - 20} more errors")
            
            # Summary of error patterns
            if len(q2_errors) > 20:
                print(f"\nError Pattern Summary (all {len(q2_errors)} errors):")
                from collections import Counter
                error_patterns = Counter([f"{e['sent']} -> {e['received']}" for e in q2_errors])
                for pattern, count in error_patterns.most_common(10):
                    print(f"  {pattern}: {count} times")
    else:
        print("No Q2 results available")
    
    print()
    print("="*70)
    print("Summary")
    print("="*70)
    if q1_total > 0 and q2_total > 0:
        print(f"Q1 Accuracy: {q1_correct}/{q1_total} = {(q1_correct/q1_total)*100:.2f}%")
        print(f"Q2 Accuracy: {q2_correct}/{q2_total} = {(q2_correct/q2_total)*100:.2f}%")
        print(f"Overall Combined Accuracy: {(q1_correct + q2_correct)/(q1_total + q2_total)*100:.2f}%")
    print("="*70)
    
    return {
        'q1_correct': q1_correct,
        'q1_total': q1_total,
        'q2_correct': q2_correct,
        'q2_total': q2_total,
        'total': len(results)
    }

# ============================================================================
# MAIN
# ============================================================================
def main():
    # Check if specific CSV provided
    if len(sys.argv) >= 2:
        csv_path = sys.argv[1]
        analyze_results(csv_path, f"Results from {os.path.basename(csv_path)}")
    else:
        # Analyze both STM32 and Python simulation results
        print("\n" + "="*70)
        print("COMPARATIVE ANALYSIS: STM32 vs Python Simulation")
        print("="*70 + "\n")
        
        stm32_stats = None
        python_stats = None
        
        # Analyze STM32 results
        if os.path.exists(STM32_CSV):
            print("\n" + "="*70)
            print("STM32 Hardware Results")
            print("="*70 + "\n")
            stm32_stats = analyze_results(STM32_CSV, "STM32 Hardware Results")
        else:
            print(f"\n⚠️  STM32 results file not found: {STM32_CSV}")
        
        # Analyze Python simulation results
        if os.path.exists(PYTHON_CSV):
            print("\n" + "="*70)
            print("Python Simulation Results")
            print("="*70 + "\n")
            python_stats = analyze_results(PYTHON_CSV, "Python Simulation Results")
        else:
            print(f"\n⚠️  Python simulation results file not found: {PYTHON_CSV}")
        
        # Comparison
        if stm32_stats and python_stats:
            print("\n" + "="*70)
            print("COMPARISON: STM32 vs Python Simulation")
            print("="*70)
            print(f"\nQ1 Accuracy:")
            print(f"  STM32:  {stm32_stats['q1_correct']}/{stm32_stats['q1_total']} = {(stm32_stats['q1_correct']/stm32_stats['q1_total'])*100:.2f}%")
            print(f"  Python: {python_stats['q1_correct']}/{python_stats['q1_total']} = {(python_stats['q1_correct']/python_stats['q1_total'])*100:.2f}%")
            print(f"\nQ2 Accuracy:")
            print(f"  STM32:  {stm32_stats['q2_correct']}/{stm32_stats['q2_total']} = {(stm32_stats['q2_correct']/stm32_stats['q2_total'])*100:.2f}%")
            print(f"  Python: {python_stats['q2_correct']}/{python_stats['q2_total']} = {(python_stats['q2_correct']/python_stats['q2_total'])*100:.2f}%")
            print("="*70)

if __name__ == "__main__":
    main()
