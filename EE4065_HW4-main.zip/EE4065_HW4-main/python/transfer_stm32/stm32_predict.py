"""
STM32 Prediction Simulator
Exactly replicates what STM32 does for digit recognition
"""

import cv2
import numpy as np
import sys
import os

# ============================================================================
# MODEL PARAMETERS (exactly as in model_q1_int.h and model_q2_int.h)
# ============================================================================
script_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(script_dir)
params_dir = os.path.join(parent_dir, "params")

# Load all parameters from quantized file
q_data = np.load(os.path.join(params_dir, "quantized_params_q15.npz"))

# Q1 parameters
hu_mean_q = q_data["mean_q1_q"].astype(np.int16)
hu_std_q = q_data["std_q1_q"].astype(np.int16)
w_q1_q = q_data["w_q1_q"].astype(np.int16)
b_q1_q = q_data["b_q1_q"].astype(np.int16)
q1_scale = int(q_data["q1_scale"] * 32768)  # Convert to Q15

# Q2 parameters
hu_mean_q2 = q_data["mean_q2_q"].astype(np.int16)
hu_std_q2 = q_data["std_q2_q"].astype(np.int16)
W1_q = q_data["W1_q"].astype(np.int16)
b1_q = q_data["b1_q"].astype(np.int16)
W2_q = q_data["W2_q"].astype(np.int16)
b2_q = q_data["b2_q"].astype(np.int16)
W3_q = q_data["W3_q"].astype(np.int16)
b3_q = q_data["b3_q"].astype(np.int16)

# ============================================================================
# STM32 FUNCTIONS (exact C logic replicated in Python)
# ============================================================================

Q15_SCALE = 1.0 / 32768.0

def relu_q15(x):
    """
    Exactly as STM32 relu_q15:
    Returns max(0, x) as int16
    """
    return int(x) if x > 0 else 0

def sigmoid_q15(x):
    """
    Exactly as STM32 sigmoid_q15:
    - Clamp at x=8 (262144 in Q15) to prevent overflow
    - Calculate sigmoid using float, return as Q15
    """
    # 8 in Q15 = 8 * 32768 = 262144
    if x > 262144:
        return 32767
    if x < -262144:
        return 0
    
    fx = float(x) * Q15_SCALE
    sig = 1.0 / (1.0 + np.exp(-fx))
    return int(sig * 32768.0)

def softmax_q15(input_arr, size):
    """
    Exactly as STM32 softmax_q15:
    1. Find maximum for numerical stability
    2. Calculate exp(x - max) and sum
    3. Normalize
    """
    max_val = input_arr[0]
    for i in range(1, size):
        if input_arr[i] > max_val:
            max_val = input_arr[i]
    
    # Calculate exp(x - max) and sum
    exp_vals = []
    sum_val = 0
    for i in range(size):
        fx = float(input_arr[i] - max_val) * Q15_SCALE
        exp_val = np.exp(fx)
        exp_vals.append(int(exp_val * 32768.0))
        sum_val += exp_vals[i]
    
    # Normalize
    output = []
    if sum_val > 0:
        for i in range(size):
            output.append(int((exp_vals[i] * 32768) // sum_val))
    else:
        # Fallback: uniform distribution
        uniform = 32768 // size
        for i in range(size):
            output.append(uniform)
    
    return output


def predict_q1(huQ15):
    """
    Exactly as STM32 LIB_NN_PredictQ1:
    1. Dot product with weights (Q15 * Q15 >> 15)
    2. Add bias
    3. Multiply by scale factor
    4. Apply sigmoid
    5. Threshold at 0.5
    """
    # Dot product
    dot_product = 0
    for i in range(7):
        # Q15 * Q15 = Q30, shift right 15 to get Q15
        product = (int(w_q1_q[i]) * int(huQ15[i])) >> 15
        dot_product += product
    
    # Add scaled bias
    sum_scaled = dot_product + int(b_q1_q[0])
    
    # Multiply by scale factor
    sum_val = (sum_scaled * q1_scale) >> 15
    
    # Apply sigmoid
    output = sigmoid_q15(sum_val)
    
    # Threshold at 0.5 (16384 in Q15)
    return 1 if output > 16384 else 0

def predict_q2(huQ15):
    """
    Exactly as STM32 LIB_NN_PredictQ2:
    1. Layer 1: 7 -> 100 (ReLU)
    2. Layer 2: 100 -> 100 (ReLU)
    3. Layer 3: 100 -> 10 (Softmax)
    4. Find max index
    
    Note: Weights are stored transposed (output_neurons, input_features)
    """
    # Cast to int32 for compatibility (STM32 uses int16_t* but we have int32_t)
    normalized = huQ15.astype(np.int32)
    
    # Layer 1: 7 -> 100 (ReLU)
    # W1_q is stored as (100, 7) in row-major: W1_q[i*7 + j] where i=output, j=input
    layer1 = np.zeros(100, dtype=np.int32)
    for i in range(100):
        sum_val = int(b1_q.flat[i])
        for j in range(7):
            w_idx = i * 7 + j  # output i, input j
            sum_val += (int(W1_q.flat[w_idx]) * int(normalized[j])) >> 15
        layer1[i] = relu_q15(sum_val)
    
    # Layer 2: 100 -> 100 (ReLU)
    # W2_q is stored as (100, 100) in row-major: W2_q[i*100 + j] where i=output, j=input
    layer2 = np.zeros(100, dtype=np.int32)
    for i in range(100):
        sum_val = int(b2_q.flat[i])
        for j in range(100):
            w_idx = i * 100 + j  # output i, input j
            sum_val += (int(W2_q.flat[w_idx]) * layer1[j]) >> 15
        layer2[i] = relu_q15(sum_val)
    
    # Layer 3: 100 -> 10 (Softmax)
    # W3_q is stored as (10, 100) in row-major: W3_q[i*100 + j] where i=output, j=input
    layer3 = np.zeros(10, dtype=np.int32)
    for i in range(10):
        sum_val = int(b3_q.flat[i])
        for j in range(100):
            w_idx = i * 100 + j  # output i, input j
            sum_val += (int(W3_q.flat[w_idx]) * layer2[j]) >> 15
        layer3[i] = sum_val
    
    # Apply softmax
    probs = softmax_q15(layer3, 10)
    
    # Find class with maximum probability
    max_idx = 0
    max_prob = probs[0]
    for i in range(1, 10):
        if probs[i] > max_prob:
            max_prob = probs[i]
            max_idx = i
    
    return max_idx


def process_image(image_path, quiet=False):
    """
    Process image exactly as STM32 does:
    1. Load grayscale image
    2. Calculate Hu moments
    3. Normalize using stored mean/std
    4. Convert to Q15
    5. Predict
    
    Args:
        image_path: Path to image file
        quiet: If True, suppress debug output
    """
    # Load image
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        if not quiet:
            print(f"Error: Could not load image {image_path}")
        return None
    
    # Resize to 28x28 if needed
    if img.shape != (28, 28):
        img = cv2.resize(img, (28, 28), interpolation=cv2.INTER_AREA)
    
    if not quiet:
        print(f"Image: {image_path}")
        print(f"Shape: {img.shape}")
        print(f"Range: [{img.min()}, {img.max()}]")
    
    # Calculate Hu moments (exactly as STM32: binaryImage=True)
    m = cv2.moments(img, binaryImage=True)
    hu = cv2.HuMoments(m).flatten()
    
    if not quiet:
        print(f"\nHu moments (raw):")
        for i, h in enumerate(hu):
            print(f"  hu[{i}] = {h:.6e}")
    
    # Normalize using stored mean/std (convert Q15 to float first)
    mean = hu_mean_q.astype(np.float32) / 32768.0
    std = hu_std_q.astype(np.float32) / 32768.0
    
    if not quiet:
        print(f"\nNormalization params (from Q15):")
        print(f"  mean = {mean}")
        print(f"  std  = {std}")
    
    # Normalize: (hu - mean) / std
    normalized = np.zeros(7, dtype=np.float32)
    for i in range(7):
        if std[i] != 0.0:
            normalized[i] = (hu[i] - mean[i]) / std[i]
        else:
            normalized[i] = 0.0
    
    if not quiet:
        print(f"\nNormalized:")
        for i, n in enumerate(normalized):
            print(f"  normalized[{i}] = {n:.6f}")
    
    # Convert to Q15 (int32_t)
    huQ15 = np.zeros(7, dtype=np.int32)
    for i in range(7):
        huQ15[i] = int(normalized[i] * 32768.0)
    
    if not quiet:
        print(f"\nQ15 format:")
        for i, q in enumerate(huQ15):
            print(f"  huQ15[{i}] = {q}")
    
    # Predict Q1
    if not quiet:
        print(f"\n{'='*60}")
        print("Q1 Prediction (Single Neuron):")
        print(f"{'='*60}")
    
    # Show calculation steps
    dot_product = 0
    for i in range(7):
        product = (int(w_q1_q[i]) * int(huQ15[i])) >> 15
        dot_product += product
        if not quiet:
            print(f"  w[{i}]={w_q1_q[i]:6d} * hu[{i}]={huQ15[i]:8d} >> 15 = {product:8d}, sum={dot_product:8d}")
    
    sum_scaled = dot_product + int(b_q1_q[0])
    if not quiet:
        print(f"\nAfter adding bias ({b_q1_q[0]}): sum_scaled = {sum_scaled}")
    
    sum_val = (sum_scaled * q1_scale) >> 15
    if not quiet:
        print(f"After scale ({q1_scale}): sum = {sum_val} (float: {sum_val/32768:.4f})")
    
    output = sigmoid_q15(sum_val)
    if not quiet:
        print(f"Sigmoid output: {output} (float: {output/32768:.4f})")
    
    q1_prediction = 1 if output > 16384 else 0
    if not quiet:
        print(f"Threshold (>16384): {output} > 16384 = {output > 16384}")
        print(f"\n{'='*60}")
        print(f"Q1 PREDICTION: {q1_prediction} ({'Digit is NOT 0' if q1_prediction == 1 else 'Digit is 0'})")
        print(f"{'='*60}")
    
    # Predict Q2 (using Q2 normalization stats)
    if not quiet:
        print(f"\n{'='*60}")
        print("Q2 Prediction (MLP) - Using Q2 normalization stats:")
        print(f"{'='*60}")
    
    # Re-normalize with Q2 stats
    mean_q2 = hu_mean_q2.astype(np.float32) / 32768.0
    std_q2 = hu_std_q2.astype(np.float32) / 32768.0
    
    normalized_q2 = np.zeros(7, dtype=np.float32)
    for i in range(7):
        if std_q2[i] != 0.0:
            normalized_q2[i] = (hu[i] - mean_q2[i]) / std_q2[i]
        else:
            normalized_q2[i] = 0.0
    
    huQ15_q2 = np.zeros(7, dtype=np.int32)
    for i in range(7):
        huQ15_q2[i] = int(normalized_q2[i] * 32768.0)
    
    if not quiet:
        print(f"\nQ2 Normalized (using Q2 stats):")
        for i, n in enumerate(normalized_q2):
            print(f"  normalized_q2[{i}] = {n:.6f}")
        print(f"\nQ2 Q15 format:")
        for i, q in enumerate(huQ15_q2):
            print(f"  huQ15_q2[{i}] = {q}")
    
    q2_prediction = predict_q2(huQ15_q2)
    
    if not quiet:
        print(f"\n{'='*60}")
        print(f"Q2 PREDICTION: {q2_prediction} (Predicted digit: {q2_prediction})")
        print(f"{'='*60}")
    
    return q1_prediction, q2_prediction


def main():
    if len(sys.argv) < 2:
        print("Usage: python stm32_predict.py <image_path>")
        print("Example: python stm32_predict.py test_images/digit_1.png")
        return
    
    image_path = sys.argv[1]
    if not os.path.exists(image_path):
        print(f"Error: File not found: {image_path}")
        return
    
    process_image(image_path)


if __name__ == "__main__":
    main()

