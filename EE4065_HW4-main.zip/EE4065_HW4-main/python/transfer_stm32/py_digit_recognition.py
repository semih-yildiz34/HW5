"""
py_digit_recognition.py
Send digit images to STM32 and receive recognition results (Q1 and Q2)
Supports single image mode or batch mode (10 cycles of all test images)
"""

import py_serialimg
import numpy as np
import cv2
import os
import sys
import time
import csv

# ============================================================================
# CONFIGURATION SECTION
# ============================================================================
COM_PORT = "COM3"  # !!! UPDATE THIS TO YOUR NUCLEO F446RE PORT !!!
TEST_IMAGES_DIR = os.path.join(os.path.dirname(__file__), "test_images")
NUM_CYCLES = 10
OUTPUT_CSV = os.path.join(os.path.dirname(__file__), "stm32_test_results.csv")

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================
def get_test_images():
    """Get list of test images in order (digit_0.png through digit_9.png)"""
    images = []
    for i in range(10):
        img_path = os.path.join(TEST_IMAGES_DIR, f"digit_{i}.png")
        if os.path.exists(img_path):
            images.append((i, img_path))
    return images

def receive_digit(max_attempts=20, timeout=0.01):
    """
    Receive a single digit from STM32, skipping header bytes.
    Returns digit (0-9) or None if not received.
    """
    for attempt in range(max_attempts):
        byte_val = py_serialimg.SERIAL_ReadByte()
        if byte_val is not None:
            # Skip "ST" header bytes (83='S', 84='T', 82='R')
            # Also skip any values > 9 that are clearly not digits
            if byte_val != 83 and byte_val != 84 and byte_val != 82 and byte_val <= 9:
                return byte_val
        time.sleep(timeout)
    return None

def process_single_image(image_path, csv_writer=None, cycle=None):
    """
    Process a single image: send to STM32 and receive Q1/Q2 results.
    Returns (q1_result, q2_result) or (None, None) on error.
    """
    try:
        # Wait for STM32 to request image
        rqType, height, width, format = py_serialimg.SERIAL_IMG_PollForRequest()
        
        if rqType == py_serialimg.MCU_READS:
            # Send image
            py_serialimg.SERIAL_IMG_Write(image_path)
            
            # Flush input buffer
            serial_obj = getattr(py_serialimg, '__serial', None)
            if serial_obj:
                serial_obj.reset_input_buffer()
            time.sleep(0.2)  # Wait for STM32 to process
            
            # Receive Q1 result
            q1_result = receive_digit()
            if q1_result is None:
                return (None, None)
            
            # Receive Q2 result
            q2_result = receive_digit()
            if q2_result is None:
                return (q1_result, None)
            
            return (q1_result, q2_result)
        else:
            return (None, None)
            
    except Exception as e:
        print(f"  ✗ ERROR: {e}")
        return (None, None)

# ============================================================================
# MAIN PROGRAM
# ============================================================================
def main():
    # Check if single image mode or batch mode
    if len(sys.argv) >= 2:
        # Single image mode
        image_path = sys.argv[1]
        
        if not os.path.exists(image_path):
            print(f"ERROR: Image file not found: {image_path}")
            return
        
        print("="*70)
        print("STM32 Digit Recognition - Single Image Mode")
        print("="*70)
        print(f"Image: {image_path}")
        print(f"COM Port: {COM_PORT}")
        print("="*70)
        
        # Initialize serial port
        print(f"\nInitializing serial port {COM_PORT}...")
        try:
            py_serialimg.SERIAL_Init(COM_PORT)
            print("✓ Serial port opened successfully")
        except Exception as e:
            print(f"\nERROR: Could not open serial port: {e}")
            return
        
        try:
            q1_result, q2_result = process_single_image(image_path)
            
            if q1_result is not None and q2_result is not None:
                print(f"\n{'='*70}")
                print(f"Recognition Complete!")
                print(f"{'='*70}")
                print(f"Q1 (Single Neuron): {q1_result} - {'Digit is 0' if q1_result == 0 else 'Digit is NOT 0'}")
                print(f"Q2 (MLP): {q2_result} - Predicted digit: {q2_result}")
                print(f"{'='*70}")
            else:
                print("ERROR: Failed to receive results")
                
        except KeyboardInterrupt:
            print("\n\nProgram stopped by user (Ctrl+C)")
        except Exception as e:
            print(f"\n\nERROR: An error occurred: {e}")
            import traceback
            traceback.print_exc()
    
    else:
        # Batch mode: 10 cycles of all test images
        print("="*70)
        print("STM32 Digit Recognition - Batch Test Mode")
        print("="*70)
        print(f"COM Port: {COM_PORT}")
        print(f"Test Images Directory: {TEST_IMAGES_DIR}")
        print(f"Number of Cycles: {NUM_CYCLES}")
        print(f"Output CSV: {OUTPUT_CSV}")
        print("="*70)
        
        # Get test images
        test_images = get_test_images()
        if len(test_images) == 0:
            print(f"\nERROR: No test images found in {TEST_IMAGES_DIR}")
            return
        
        print(f"\nFound {len(test_images)} test images:")
        for digit, path in test_images:
            print(f"  digit_{digit}.png")
        
        # Initialize serial port
        print(f"\nInitializing serial port {COM_PORT}...")
        try:
            py_serialimg.SERIAL_Init(COM_PORT)
            print("✓ Serial port opened successfully")
        except Exception as e:
            print(f"\nERROR: Could not open serial port: {e}")
            return
        
        # Prepare CSV file
        csv_file = open(OUTPUT_CSV, 'w', newline='')
        csv_writer = csv.writer(csv_file)
        csv_writer.writerow(['sent_digit', 'q1_received', 'q2_received'])
        
        total_tests = NUM_CYCLES * len(test_images)
        test_count = 0
        success_count = 0
        
        try:
            print(f"\n{'='*70}")
            print(f"Starting batch test: {NUM_CYCLES} cycles × {len(test_images)} images = {total_tests} total tests")
            print(f"{'='*70}\n")
            
            for cycle in range(1, NUM_CYCLES + 1):
                print(f"\n--- CYCLE {cycle}/{NUM_CYCLES} ---")
                
                for digit, image_path in test_images:
                    test_count += 1
                    
                    print(f"\n[{test_count}/{total_tests}] Processing digit_{digit}.png...")
                    q1_result, q2_result = process_single_image(image_path, csv_writer, cycle)
                    
                    if q1_result is not None and q2_result is not None:
                        success_count += 1
                        print(f"  ✓ Sent: {digit}, Q1: {q1_result}, Q2: {q2_result}")
                        csv_writer.writerow([digit, q1_result, q2_result])
                        csv_file.flush()  # Ensure data is written immediately
                    else:
                        print(f"  ✗ ERROR: Failed to receive results")
                        csv_writer.writerow([digit, 'ERROR', 'ERROR'])
                        csv_file.flush()
                    
                    # If this is the last image (digit_9) of the last cycle, we're done
                    if cycle == NUM_CYCLES and digit == 9:
                        print(f"\n{'='*70}")
                        print(f"Batch test complete!")
                        print(f"  Total tests: {test_count}")
                        print(f"  Successful: {success_count}")
                        print(f"  Failed: {test_count - success_count}")
                        print(f"  Results saved to: {OUTPUT_CSV}")
                        print(f"{'='*70}")
                        csv_file.close()
                        return
            
            # Final summary (shouldn't reach here if ending after digit_9)
            print(f"\n{'='*70}")
            print(f"Batch test complete!")
            print(f"  Total tests: {test_count}")
            print(f"  Successful: {success_count}")
            print(f"  Failed: {test_count - success_count}")
            print(f"  Results saved to: {OUTPUT_CSV}")
            print(f"{'='*70}")
            csv_file.close()
            
        except KeyboardInterrupt:
            print("\n\nProgram stopped by user (Ctrl+C)")
            print(f"Partial results saved to: {OUTPUT_CSV}")
            csv_file.close()
        except Exception as e:
            print(f"\n\nERROR: An error occurred: {e}")
            import traceback
            traceback.print_exc()
            csv_file.close()

if __name__ == "__main__":
    main()
